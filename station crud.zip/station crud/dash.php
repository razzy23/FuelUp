<?php
session_start();
$mysqli = require __DIR__ . "/database.php";



//echo('<br/>Success: A proper connection to MySQL was made.<br/> Host information: '.$mysqli->host_info.'<br/> Protocol version: '.$mysqli->protocol_version);
//connection to mySQL database

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location:index.html");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dash.css">
    <title>Dashboard</title>
</head>

<style>
    

    .container2 .card .percent svg {
        position: relative;
        width: 250px;
        height: 250px;

    }

    .container2 .card .percent svg circle {
        width: 100px;
        height: 100px;
        fill: transparent;
        stroke-width: 5;
        stroke: #EEEEEE;
        transition: translate(5px, 5px);
    }

    .container2 .card .percent svg circle:nth-child(2) {
        stroke: var(--clr);
        stroke-dasharray: 555;
        stroke-dashoffset: calc(555 - (555* var(--num))/ 100);
    }

    .dot {
        position: absolute;
        inset: 6px;
        z-index: 10;

        animation: animate 2s linear forwards;

    }

    @keyframes animateDot {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(calc(3.6deg * var(--num)));
        }
    }

    .dot::before {
        content: "";
        position: absolute;
        top: 17px;
        left: 51px;
        transform: translateX(-50%);
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--clr);
        box-shadow: 0 0 10px var(--clr), 0 0 30px var(--clr);
    }

    .number {
        position: absolute;
        inset: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        transform: rotate(90deg);
    }

    .number h2 {
        display: flex;
        justify-content: center;
        align-items: center;
        color: #35363A;
        font-weight: 1000;
    }

    .number h2 span {

        color: #35363A;
        font-weight: 300;
    }

    .number p {
        color: #35363A;
    }
</style>


<body class="body">
    <nav>
        <ul class="navlink">
            <img src="imgs/logo3.png" alt="logo" class="logonav">
            <li><a href="#about">History</a></li>
            <li><a href="#contact">Complaints</a></li>
            <li><a class="active" href="#home">Add Employee</a></li>
            <li><a href="#news">Re Stock</a></li>
            <li><a href="#about">Dashboard</a></li>
        </ul>
    </nav>
    <div class="split left">
        <div class="container2">
            <div class="card">
                <div class="percent" style="--clr:#E14761;--num:85;">
                    <div class="dot">
                        <svg>
                            <circle cx="100" cy="95" r="88"></circle>
                            <circle cx="100" cy="95" r="88"></circle>
                        </svg>

                        <div class="number">
                            <h2>85<span>%</span></h2>
                            <p>petrol-92</p>
                        </div>
                    </div>
                </div>

            </div>

            <div class="card">
                <div class="percent" style="--clr:#E14761;--num:79;">
                    <div class="dot">
                        <svg>
                            <circle cx="100" cy="95" r="88"></circle>
                            <circle cx="100" cy="95" r="88"></circle>
                        </svg>
                        <div class="number">
                            <h2>79<span>%</span></h2>
                            <p>petrol-95</p>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card">
                <div class="percent" style="--clr:#E14761;--num:60;">
                    <div class="dot">
                        <svg>
                            <circle cx="100" cy="95" r="88"></circle>
                            <circle cx="100" cy="95" r="88"></circle>
                        </svg>
                        <div class="number">
                            <h2>60<span>%</span></h2>
                            <p>Super Diesel</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="percent" style="--clr:#E14761;--num:50;">
                    <div class="dot">
                        <svg>
                            <circle cx="100" cy="95" r="88"></circle>
                            <circle cx="100" cy="95" r="88"></circle>
                        </svg>
                        <div class="number">
                            <h2>50<span>%</span></h2>
                            <p>Diesel</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="percent" style="--clr:#E14761;--num:90;">
                    <div class="dot">
                        <svg>
                            <circle cx="100" cy="95" r="88"></circle>
                            <circle cx="100" cy="95" r="88"></circle>
                        </svg>
                        <div class="number">
                            <h2>90<span>%</span></h2>
                            <p>petrol</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="split right">
        <?php echo ("Welcome " . $_SESSION['user_id']); ?>
        <img src="imgs/profile1.png" alt="profile" class="profile">
        <div>
            <div class="container">
                <a href="add.php">
                    <div class="box">
                        Add employee
                    </div>
                </a>
                <a href="add.php">
                    <div class="box">
                        Restock
                    </div>
                </a>
                <a href="add.php">
                    <div class="box">
                        Complaints
                    </div>
                </a>
                <a href="add.php">
                    <div class="box">
                        History
                    </div>
                </a>
            </div>
            <form method="post">
                <a class="bottomright" href="logout.php">
                    <div class="logout">
                        Logout
                    </div>
                </a>
            </form>
        </div>

        <div>

</body>



</html>