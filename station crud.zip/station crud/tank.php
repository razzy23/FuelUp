<?php
session_start();
$sid = $_SESSION['userid'];

$mysqli = require __DIR__ . "/database.php";

echo $sid;


$petrol92 = $_POST['petrol92'];
$petrol95 = $_POST['petrol95'];
$diesel = $_POST['diesel'];
$superdiesel = $_POST['superdiesel'];
$kerosene = $_POST['kerosene'];


$sql = "UPDATE stationreg  SET petrol92='$petrol92',petrol95='$petrol95',diesel='$diesel',superdiesel='$superdiesel',kerosene='$kerosene' WHERE station_id='$sid' ";

$result = mysqli_query($mysqli, $sql);

if ($result) {
    header("Location:signup-success.html");
} else {
    echo ("datanot updated");
}

mysqli_close($mysqli);
