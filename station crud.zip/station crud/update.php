<?php

$mysqli = require __DIR__ . "/database.php";
$id = $_GET['updateid'];

$sql = "SELECT * FROM pump_operator WHERE id=$id";
$result = mysqli_query($mysqli, $sql);
$row = mysqli_fetch_assoc($result);
$uid = $row['operator_id'];
$name = $row['name'];
$mobile = $row['mobile'];
$password = $row['password'];



if (isset($_POST['submit'])) {
    $uid = $_POST["opid"];
    $name = $_POST["name"];
    $mobile = $_POST["mobile"];
    $password = $_POST["password"];
    $passwordconf = $_POST["passwordconf"];

    // if (strlen($password) < 8) {
    //     die("Password must be at least 8 characters");
    // }

    // if (!preg_match("/[a-z]/i", $password)) {
    //     die("Password must contaain at leasst one letter");
    // }

    // if (!preg_match("/[0-9]/i", $password)) {
    //     die("Password must contaain at leasst one number");
    // }

    // if ($password !== $passwordconf) {
    //     die("Password must match");
    // }

    $sql = "UPDATE pump_operator
    SET operator_id = '$uid', name = '$name', mobile = '$mobile', password = '$password'
    WHERE id=$id";

    $result = mysqli_query($mysqli, $sql);
    if ($result) {
        header('location:display.php');
    } else {
        die(mysqli_error($mysqli));
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="employe.css" rel="stylesheet">
    <title>Document</title>
</head>
<style>
    .buttonup {
        width: 40%;
  background-color: #E14761;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;

  
    }
</style>

<nav>
    <ul class="navlink">
        <img src="./imgs/logo3.png" alt="logo" class="logonav">
        <li><a class="active" href="dash.php">History</a></li>
        <li><a class="active" href="dash.php">Complaints</a></li>
        <li><a class="active" href="add.php">Add Employee</a></li>
        <li><a class="active" href="dash.php">Re Stock</a></li>
        <li><a class="active" href="dash.php">Dashboard</a></li>
    </ul>
</nav>

<body>
    <div class="list">
        <a href="display.php" role="button">employee list</a>
    </div>

    <h1 style="text-align:center;">Update pump operator </h1>

    <form method="POST" id="form">
        <div>
            <label for="opid">Operator ID </label>
            <input type="text" id="opid" name="opid" placeholder="Enter opertor id" autocomplete="off" value=<?php echo $uid; ?> required>
        </div>
        <div>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" placeholder="Enter operator name" autocomplete="off" value=<?php echo $name; ?> required>
        </div>
        <div>
            <label for="mobile">Mobile</label>
            <input type="text" id="mobile" name="mobile" placeholder="Enter opertor mobile" autocomplete="off" value=<?php echo $mobile; ?> required>
        </div>
        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter opertor password" autocomplete="off" value=<?php echo $password; ?> required>
        </div>
        <div>
            <label for="passwordconf">Repeat password</label>
            <input type="password" id="passwordconf" name="passwordconf" placeholder="Reenter password" autocomplete="off" value=<?php echo $password; ?> required>
        </div>
        <div>
            <button type="submit" name="submit">Update</button>
            <a href="display.php" class="buttonup">Cancel</a>
        </div>
    </form>



</body>

</html>