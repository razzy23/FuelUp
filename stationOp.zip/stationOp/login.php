<?php

$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $mysqli = require __DIR__ . "/database.php";

    $sql = sprintf(
        "SELECT * FROM stationreg WHERE station_id='%s'",
        $mysqli->real_escape_string($_POST["stid"])
    );


    $result = $mysqli->query($sql);

    $user = $result->fetch_assoc();

    if ($user) {
        if (password_verify($_POST["password"], $user["password_hash"])) {
            session_start();
            session_regenerate_id();

            $_SESSION["user_id"] = $user["id"];

            header("Location:index.php");
            exit;
        }
    }
    $is_invalid = true;
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<h1>, initial-scale=1.0">
    <link href="mainstyle.css" rel="stylesheet">
    <title>Login</title>
</head>

<body>
    <nav>
        <ul class="navlink">
            <li><a class="active" href="#home">Home</a></li>
            <li><a href="#news">News</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="#about">About</a></li>
        </ul>
    </nav>
    <?php if ($is_invalid) : ?>
        <em>Invalid login</em>

    <?php else : ?>
    <diV class="mainbox">
    <div>
        <img src="imgs/logo2.png" alt="logo" id="logo2">
    </div>
    <div style="justify-content: space-between">
      <h1>Login</h1>
      <a href="ulogin.html" id="mis">Have an account? Sign in instead</a>
    <form method="post">
    <div>
                <label for="stid">station_id</label>
                <input type="text" id="stid" name="stid" value="<?= htmlspecialchars($_POST["stid"] ?? "") ?>" required>
            </div>
            <div>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <input type="submit" value="Login">

    </form>  
    </div>
    
  </diV>

    <?php endif; ?>
</body>

</html>