<?php
session_start();
$mysqli = require __DIR__ . "/database.php";;


//echo('<br/>Success: A proper connection to MySQL was made.<br/> Host information: '.$mysqli->host_info.'<br/> Protocol version: '.$mysqli->protocol_version);
//connection to mySQL database

if (isset($_POST['logout'])) {
    session_destroy();
    header("Location:index.html");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dash.css">
    <title>Dashboard</title>
</head>



<body class="body">
    <nav>
        <ul class="navlink">
            <img src="imgs/logo3.png" alt="logo" class="logonav">
            <li><a href="#about">History</a></li>
            <li><a href="#contact">Complaints</a></li>
            <li><a class="active" href="#home">Add Employee</a></li>
            <li><a href="#news">Re Stock</a></li>
            <li><a href="#about">Dashboard</a></li>
        </ul>
    </nav>
    <div class="split left">
        <img src="imgs/logo3.png" alt="logo" class="logonav">
    </div>



    <div class="split right">
        <?php echo ("Welcome " . $_SESSION['user_id']); ?>
        <img src="imgs/profile1.png" alt="profile" class="profile">
        <div>
            <div class="container">
                <a href="employee/add.php">
                    <div class="box">
                        Add employee
                    </div>
                </a>
                <a href="employee/add.php">
                    <div class="box">
                        Restock
                    </div>
                </a>
                <a href="employee/add.php">
                    <div class="box">
                        Complaints
                    </div>
                </a>
                <a href="employee/add.php">
                    <div class="box">
                        History
                    </div>
                </a>
            </div>
            <form method="post">
                <a class="bottomright" href="logout.php">
                    <div class="logout">
                        Logout
                    </div>
                </a>
            </form>
        </div>

        <div>




</body>



</html>