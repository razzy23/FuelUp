<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="employe.css" rel="stylesheet">
    <title>Document</title>
</head>
<ul class="navlink">
    <img src="../imgs/logo3.png" alt="logo" class="logonav">
    <li><a href="#about">History</a></li>
    <li><a href="#contact">Complaints</a></li>
    <li><a class="active" href="#home">Add Employee</a></li>
    <li><a href="#news">Re Stock</a></li>
    <li><a href="#about">Dashboard</a></li>
</ul>
</nav>

<body>
    <div>
        <div class="list">
            <a href="add.php" role=button>Add new Operator</a>
        </div>
        <div style="text-align:center;">
            <h2>List of Pump Operators</h2>
            <br>
            <table id="table">
                <thead>
                    <tr>
                        <th>Operator ID</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Password</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                    $mysqli = require __DIR__ . "/database.php";

                    $sql = "SELECT * FROM pump_operators";
                    $result = mysqli_query($mysqli, $sql);

                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $uid = $row['operator_id'];
                            $name = $row['name'];
                            $mobile = $row['mobile'];
                            $password = $row['password'];
                            echo "
                    <tr>
                    <td>$uid</td>
                    <td>$name</td>
                    <td>$mobile</td>
                    <td>$password</td>
                    <td>
                    <button class= 'button'><a href='/update.php'>Update</a> </button>
                    <button class= 'button'><a href='/delete.php? deleteid=".$uid."'>Delete</a> </button>
                        
                    </td>
                </tr>
                    ";
                        }
                    }

                    ?>

                </tbody>
            </table>
        </div>

    </div>

</body>

</html>