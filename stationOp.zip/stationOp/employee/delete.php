<?php
$mysqli = require __DIR__ . "/database.php";

if (isset($_GET['deleteid'])) {
    $uid = $_GET['deleteid'];

    $sql = "DELETE FROM pump_operators where id=$uid";
    $result = mysqli_query($mysqli, $sql);
    if ($result) {
        echo ("yyy");
    } else {
        die(mysqli_error($mysqli));
    }
}
