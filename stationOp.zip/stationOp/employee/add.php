<?php

$mysqli = require __DIR__ . "/database.php";

if (isset($_POST['submit'])) {
    $uid = $_POST["opid"];
    $name = $_POST["name"];
    $mobile = $_POST["mobile"];
    $password = $_POST["password"];
    $passwordconf = $_POST["passwordconf"];

    if (strlen($password) < 8) {
        die("Password must be at least 8 characters");
    }

    if (!preg_match("/[a-z]/i", $password)) {
        die("Password must contaain at leasst one letter");
    }

    if (!preg_match("/[0-9]/i", $password)) {
        die("Password must contaain at leasst one number");
    }

    if ($password !== $passwordconf) {
        die("Password must match");
    }

    $sql = "INSERT INTO pump_operators (operator_id, name, mobile, password)
    VALUES (?, ?, ?, ?)";


    $stmt = $mysqli->stmt_init();



    if (!$stmt->prepare($sql)) {         //to check syntax error in insert sql
        die("SQL error:" . $mysqli->error);
    }

    $stmt->bind_param(
        "ssss",
        $_POST["opid"],
        $_POST["name"],
        $_POST["mobile"],
        $_POST["password"],
    );

    if ($stmt->execute()) {
        header("Location: tank.html");
    } else {
        if ($mysqli->errno === 1062) {
            die("operator id already taken");
        } else {
            die($mysqli->error . " " . $mysqli->errno);
        }
    };
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="employe.css" rel="stylesheet">
    <title>Document</title>
</head>
<nav>
    <ul class="navlink">
        <img src="../imgs/logo3.png" alt="logo" class="logonav">
        <li><a href="#about">History</a></li>
        <li><a href="#contact">Complaints</a></li>
        <li><a class="active" href="#home">Add Employee</a></li>
        <li><a href="#news">Re Stock</a></li>
        <li><a href="#about">Dashboard</a></li>
    </ul>
</nav>

<body>
    <div class="list">
        <a href="display.php" role="button">employee list</a>
    </div>

    <h1 style="text-align:center;">Add pump operator </h1>

    <form method="POST" id="form">
        <div>
            <label for="opid">Operator ID </label>
            <input type="text" id="opid" name="opid" required>
        </div>
        <div>
            <label for="name">Name</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div>
            <label for="mobile">Mobile</label>
            <input type="text" id="mobile" name="mobile" required>
        </div>
        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div>
            <label for="passwordconf">Repeat password</label>
            <input type="password" id="passwordconf" name="passwordconf" required>
        </div>
        <div>
            <button type="submit" name="submit">Add</button>
        </div>
    </form>



</body>

</html>