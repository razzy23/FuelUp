<?php

$mysqli = require __DIR__ . "/database.php";

if (isset($_GET['deleteid'])) {
    $id = $_GET['deleteid'];

    $sql = "DELETE FROM pump_operators WHERE id=$id";
    $result = mysqli_query($mysqli, $sql);
    if ($result) {
        //echo "d s";
        header('location:display.php');
    } else {
        die(mysqli_error($mysqli));
    }
}
