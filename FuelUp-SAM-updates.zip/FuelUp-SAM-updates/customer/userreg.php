<html>
  <head>
    <title>Recieving data</title>
  </head>
  <body>
    <h1>Data recieved from the user registration form</h1>
    <div class="signupFrm">
        <img src="../imgs/logo2.png" alt="logo" id="logo2">
        <form action="" method="POST" class="form" >
          <div id="regorlogin">
            <h1 class="title">User registration</h1>
            <a href="ulogin.html" id="mis">Have an account? Sign in instead</a>
          </div>
    
          <div class="inputContainer">
            <input type="text" name="nic" class="input" placeholder="a"required>
            <label for="" class="label">NIC</label>
          </div>

          <div class="inputContainer">
            <input type="text" name="phone" class="input" placeholder="a" required>
            <label for="" class="label">Phone number</label>
          </div>
    
          <div class="inputContainer">
            <input type="text" name="uname" class="input" placeholder="a" required>
            <label for="" class="label">Username</label>
          </div>

          <div class="inputContainer">
            <input type="text" name="email" class="input" placeholder="a" >
            <label for="" class="label">Email</label>
          </div>
    
          <div class="inputContainer">
            <input type="text" name="pass" class="input" placeholder="a" required>
            <label for="" class="label">Password</label>
          </div>
    
          <div class="inputContainer">
            <input type="text" name="conf" class="input" placeholder="a" required>
            <label for="" class="label">Confirm Password</label>
          </div>

          <input type="submit" class="submitBtn" value="Next">
        </form>
      </div>
    <p>
      <?php
      session_start();

      $nic = $_POST['nic'];
      $_SESSION['nic'] = $nic;
      $phone=$_POST['phone'];
      $_SESSION['phone'] = $phone;
      $_SESSION['uname'] = $_POST['uname'];
      $email = $_POST['email'];
      $_SESSION['email'] = $email;
      $pass = $_POST['pass'];
      $_SESSION ['pass'] = $pass;
      $conf = $_POST['conf']; 
      //getting data from the form

      if($pass != $conf){
        die ("Registration error:<br/>Passwords do not match");
      }
      if($email != null){
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
          die ("Registration error:<br/>Invalid email address"); //emails can be null or should have a correct entry
        }
      }
      if(strlen($nic) > 12){
        die ("Invalid NIC");
      }
      //validation

      header("Location: vehreg.php", true, 301);

?>
    </p>
  </body>
</html>