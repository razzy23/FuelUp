<?php 
session_start ();
?>
<!DOCTYPE html>
<html>

   <head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>

.navbar {
  overflow: hidden;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

</style>
   <link href="history.css" rel="stylesheet">
      <title>History</title>
       <script src="//code.jquery.com/jquery.min.js"></script>
    <script>
        $.get("nav.html", function(data){
            $("#nav-placeholder").replaceWith(data);
            document.getElementById("orgs").style.color = "#E14761";
        });
        
    </script>

   </head>

   <body>
  <div id="nav-placeholder"></div>  
   <a href="#filters">Filters</a>
  <a href="#stations">Stations</a>
<select name="stations" id="stations">
  <option value="station0">Select a station:</option>
  <option value="station1">Colombo</option>
  <option value="station2">Gampaha</option>
  <option value="station3">Kalutara</option>
</select> 


<table style="width:100%">
  <tr>
    <th>Date</th>
    <th>Station</th>
    <th>Vehicle</th>
    <th>Driver</th>
    <th>Amount</th>
    <th>Price</th>
  </tr>
  <tr>
    <td>2020/09/09</td>
    <td>Colombo</td>
    <td>Car</td>
    <td>Saman</td>
    <td>5l</td>
    <td>1000 LKR</td>
  </tr>
  <tr>
    <td>2020/09/19</td>
    <td>Colombo</td>
    <td>Car</td>
    <td>Saman</td>
    <td>5l</td>
    <td>1800 LKR</td>
  </tr>
</table>
