<?php
    include 'databaseaccess.php';

    $id = $_SESSION['id'];
    $result = $conn->query($sql);
    if($result == True){
        session_destroy();
        header("Location: ulogin.php");
    }else{
        echo "logout Error";
    }
?>