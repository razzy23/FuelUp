<?php
include 'databaseaccess.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../style.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div class="signupFrm">
        <img src="../imgs/logo2.png" alt="logo" id="logo2">
        
        <form action="ulogin.php" method="POST" class="form" >
            <div id="regorlogin">
                <h1 class="title">User Login</h1>
                <a href="userreg.php" id="mis">Don't have an account? Sign up instead</a>
            </div>
          <div class="inputContainer">
            <input type="text" name="phone" class="input" placeholder="a" required>
            <label for="" class="label">Phone number</label>
          </div>
    
          <div class="inputContainer">
            <input type="text" name="pass" class="input" placeholder="a" required>
            <label for="" class="label">Password</label>
          </div>

          <input type="submit" class="submitBtn" value="Login">
        </div>
        </form>
      </div>
</body>
</html>
      <?php
        $phone = $_POST['phone'];
        $pass = $_POST['pass'];
        //getting data from the form

        if(strlen($phone)>10){
          header("Location: ./ulogin.php", true, 301);
          die ("Invalid number");
        }

        $sql = "SELECT * FROM users WHERE phone = '$phone' AND password = '$pass'";
        //getting data from the database

        $result = $mysqli->query($sql);
        $row = $result->fetch_assoc();
        //checking if the user exists

        if (is_array($row)) {
          $_SESSION['uname'] = $row['name'];
          $_SESSION['id'] = $row['nic'];
          echo('login successful');
          echo('<script>alert("Login successful");</script>');
          header("Location: dash.php", true, 301);
          //redirect to dashboard page
        } else {
          echo ('<script>alert("Invalid credentials");</script>');
        }
  $mysqli->close();
?>